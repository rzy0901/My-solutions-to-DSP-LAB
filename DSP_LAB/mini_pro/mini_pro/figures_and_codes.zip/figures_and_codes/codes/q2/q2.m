clear;
freq_2_D=num2freq(2,'D');
disp(freq_2_D); 